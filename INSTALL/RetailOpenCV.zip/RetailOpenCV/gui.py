import numpy as np
import cv2
import config as cf
import time
import logging
from Source import Source
from ForgroundExtraction import ForgroundExtraction
from Person import Person
import math
from copy import copy
from Tkinter import *


root = Tk()





root.title("Tracking")




root.mainloop()